"""f2 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import re_path as url
from django.urls import path
from django.contrib import admin
import Sample.views
from django.conf import settings


urlpatterns = [
    path('admin/', admin.site.urls),
    path('about/',Sample.views.about),
    path('',Sample.views.Login,name="Login"),
    path('asd/',Sample.views.asd,name="asd"),
    path('main/',Sample.views.main),
    
    path('addstudent/',Sample.views.add_students, name="addstudent"),
    
    path('capture/',Sample.views.capture, name="capture"),
    path('train/',Sample.views.training,name='training'),
    path('rec/',Sample.views.recg,name='recg'),
    path('search/',Sample.views.search,name='search'),
    path('logout/',Sample.views.logout,name='logout'),
    path('attendance/',Sample.views.attendance,name="attendance"),
    path('view_att/',Sample.views.home,name="view_att"),
    path('takenatt/',Sample.views.takenatt,name="takenatt"),
    
    path('add_course/',Sample.views.add_course,name="add_course"),
    path('add_lecture/',Sample.views.add_lecture,name="add_lecture"),
    path('add_class/',Sample.views.add_class,name="add_class"),
    path('take_attendance/',Sample.views.take_attendance,name="take_attendance"),
    
    path('Lec_cap',Sample.views.Lec_capture,name="Lec_cap"),
    path('S/',Sample.views.back,name="back"),
    path('Lec/',Sample.views.training_lec,name="training_lec"),
    path('traineigen/',Sample.views.trainingeigen,name='trainingeigen'),
    path('receigen/',Sample.views.recgeigen,name='recgeigen'),
    
    
    #path('faceCheckinRecog/',Sample.views.faceCheckinRecog,name='faceCheckinRecog')


]