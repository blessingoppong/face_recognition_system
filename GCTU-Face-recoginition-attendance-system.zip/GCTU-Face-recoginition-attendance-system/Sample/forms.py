from django import forms
from .models import *


class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = (  
                    'name',
                    'student_id',
                    'Class',
                    'course',
                    'faculty',
                    'email',
                )
        
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'required':'True'}),
            'student_id': forms.NumberInput(attrs={'class': 'form-control', 'required':'True'}),
            'Class': forms.Select(attrs={'class': 'form-control', 'required':'True'}),
            'course': forms.Select(attrs={'class': 'form-control', 'required':'True'}),            
            'faculty': forms.Select(attrs={'class': 'form-control', 'required':'True'}),            
            'email': forms.EmailInput(attrs={'class': 'form-control', 'required':'True'}),            
        }
        
        
             
        
class LectureForm(forms.ModelForm):
    class Meta:
        model = Lecture
        fields = (  
                    'lecture_email',
                    'lecture_name',
                    'faculty',
                )
        
        widgets = {
            'lecture_email': forms.TextInput(attrs={'class': 'form-control', 'required':'True'}),
            'lecture_name': forms.TextInput(attrs={'class': 'form-control', 'required':'True'}),
            'faculty': forms.Select(attrs={'class': 'form-control', 'required':'True'}),            
        }



class CoursesForm(forms.ModelForm): 
    class Meta:
        model = Courses
        fields = (  
                    'course_name',
                    'course_code',
                    'lecture',
                )
        
        widgets = {
            'course_name': forms.TextInput(attrs={'class': 'form-control', 'required':'True'}),
            'course_code': forms.TextInput(attrs={'class': 'form-control', 'required':'True'}),
            'lecture': forms.Select(attrs={'class': 'form-control', 'required':'True'}),            
        }



class ClassForm(forms.ModelForm): 
    class Meta:
        model = Class
        fields = (  
                    'class_name',
                    #'lecture',
                )
        
        widgets = {
            'class_name': forms.TextInput(attrs={'class': 'form-control', 'required':'True'}),
            #'lecture': forms.Select(attrs={'class': 'form-control', 'required':'True'}),            
        }




class AttendanceForm(forms.ModelForm): 
    class Meta:
        model = Attendance
        fields = (  
                    'lecture',
                    'student_class',
                )
        
        widgets = {
            'student_class': forms.Select(attrs={'class': 'form-control', 'required':'True'}),
            'lecture': forms.Select(attrs={'class': 'form-control', 'required':'True'}),            
        }







