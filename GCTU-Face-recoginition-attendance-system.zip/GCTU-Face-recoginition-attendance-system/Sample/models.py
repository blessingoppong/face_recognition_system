from django.db import models
from django.utils import timezone



class Lecture(models.Model):
    faculty_choices = (('FoCIS', 'FoCIS'), ('Enginnering', 'Enginnering'), ('Business', 'Business'))
    lecture_email = models.CharField(max_length=64, null=True, blank=True)
    lecture_name = models.CharField(max_length=64, null=True, blank=True)
    faculty = models.CharField(max_length=64, null=True, blank=True, choices=faculty_choices)
    date_created = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.lecture_name
    
    
    
class Courses(models.Model):
    course_name = models.CharField(max_length=64, null=True, blank=True)
    course_code = models.CharField(max_length=64, null=True, blank=True)
    lecture = models.ForeignKey(Lecture, on_delete=models.CASCADE, null=True, blank=True)
    date_created = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "course"
        verbose_name_plural = "courses"
        
        
    def __str__(self):
        return self.course_name





class Class(models.Model):
    class_name = models.CharField(max_length=64, null=True, blank=True)
    #lecture = models.ForeignKey(Lecture, on_delete=models.CASCADE, null=True, blank=True)
    date_created = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.class_name



class Student(models.Model):
    faculty_choices = (('FoCIS', 'FoCIS'), ('Enginnering', 'Enginnering'), ('Business', 'Business'))
    name = models.CharField(max_length=100, null=True, blank=True)
    student_id = models.CharField(max_length=64, null=True, blank=True)
    Class = models.ForeignKey(Class, on_delete=models.CASCADE, related_name='student_class', )
    course = models.ForeignKey(Courses, on_delete=models.CASCADE, related_name='student_course', )
    faculty = models.CharField(max_length=100, null=True, blank=True, choices=faculty_choices)
    email = models.CharField(max_length=100, null=True, blank=True)
    date_created = models.DateTimeField(auto_now=True)
    
    
    def __str__(self):
        return self.student_id



class Attendance(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, blank=True, null=True)
    lecture = models.ForeignKey(Lecture, on_delete=models.CASCADE, blank=True, null=True)
    student_class = models.ForeignKey(Class, on_delete=models.CASCADE, null=True, blank=True)
    present = models.BooleanField(default=False)
    date_created = models.DateTimeField(default=timezone.now)
    
    
    def __str__(self):
        return self.student.student_id
    
