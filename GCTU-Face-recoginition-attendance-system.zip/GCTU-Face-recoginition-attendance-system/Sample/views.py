from django.shortcuts import render,get_object_or_404,redirect
from django.http import HttpResponseRedirect,HttpResponse
from django.core.mail import send_mail
from django.conf import settings
from django.urls import reverse
from django.contrib.auth import (login as auth_login, logout as _logout,  authenticate)
from Sample.models import *
from django.db import IntegrityError

from .models import *
from .forms import *

#from background_task import background
import cv2 , csv,time
import os , schedule
import numpy as np
from PIL import Image 
import math, datetime
from f2.settings import BASE_DIR
from django.contrib import messages 


# Checks if user truly exists in the database
def user_exists(student_id):
    if Student.objects.filter(student_id=student_id).exists():
        return True
    
    return False


def Login(request):
    msg='Please Sign in'
    if request.method == 'POST':
        _uname= request.POST['name']
        _password = request.POST['password']
        user = authenticate(username=_uname,password = _password)
        if user is not None:
            if user.is_active:
                auth_login(request,user)
                return HttpResponseRedirect('/main/')
            else:
                msg='Not login'
        else:
            msg='Invalid Username and password'
    context = {'message':msg}
    return render(request,'Login.html',context)
        
def  about(request):
    return render(request,'about.html')

def  home(request):
    return render(request,'view_attendance.html')


def main(request):
    if not request.user.is_authenticated:
        return render(request, 'Login.html')
    else:
        
        date =datetime.datetime.now()
        print((date.isoweekday() % 7))
        return render(request,'main.html')




def add_course(request):

    if not request.user.is_authenticated:
        messages.error(request, 'You need to login to this page')
        return render(request,'Login.html')
    else :
        form = CoursesForm()
        if request.method =='POST':
            form = CoursesForm(request.POST)
            if form.is_valid():
                
                form.save()
                messages.success(request, 'Course registered successfully!')
            else:
                messages.error(request, 'There was an error saving course info!')
      
    context = {'form':form}
    return render(request, 'add_course.html', context)






def add_lecture(request):

    if not request.user.is_authenticated:
        messages.error(request, 'You need to login to this page')
        return render(request,'Login.html')
    else :
        form = LectureForm()
        if request.method =='POST':
            form = LectureForm(request.POST or None)
            if form.is_valid():
                
                form.save()
                messages.success(request, 'Lecture registered successfully!')
            else:
                messages.success(request, 'There was an error saving lecture info!')
      
    context = {'form': form}
    return render(request, 'add_lecture.html', context)





def add_class(request):

    if not request.user.is_authenticated:
        messages.error(request, 'You need to login to this page')
        return render(request,'Login.html')
    else :
        form = ClassForm()
        if request.method =='POST':
            form = ClassForm(request.POST or None)
            if form.is_valid():
                
                form.save()
                messages.success(request, 'Class registered successfully!')
            else:
                messages.error(request, 'There was an error saving class info!')
      
    context = {'form': form}
    return render(request, 'add_class.html', context)





def add_students(request):
    
    if not request.user.is_authenticated:
        messages.error(request, 'You need to login to this page')
        return render(request,'Login.html')
    else :
        
        if request.method == "POST": 
        
            form = StudentForm(request.POST or None)
               

            context = {'form': form}
            print(form.is_valid())
            if form.is_valid():
                
                # email = user_form.cleaned_data.get("email")
                student_id = form.cleaned_data.get("student_id")
                
                
                student = form.save(commit=False)  # Don't save yet

                # check if face already exist 
                counter = 0
        
                faceDetect = cv2.CascadeClassifier(str(BASE_DIR)+'/ml/haarcascade_frontalface_default.xml')

                cam = cv2.VideoCapture(0)
                # creating recognizer
                rec = cv2.face.LBPHFaceRecognizer_create()
                # loading the training data
                rec.read(str(BASE_DIR)+'/ml/recognizer/trainingData.yml')
                getId = 0
                font = cv2.FONT_HERSHEY_SIMPLEX
                userId = 0
                
                while(True):
                    ret, img = cam.read()
                    try:
                        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                        faces = faceDetect.detectMultiScale(gray, 1.3, 5)
                    except:
                        messages.error(request, 'Please check your camera and continue')
                        return render(request, 'addstudent.html', context)
                    
                    
                    for(x,y,w,h) in faces:
                        cv2.rectangle(img,(x,y),(x+w,y+h), (0,255,0), 2)

                        getId,conf = rec.predict(gray[y:y+h, x:x+w]) #This will predict the id of the face

                        #print conf;
                        if conf<25:
                            userId = getId
                            cv2.putText(img, "Detected",(x,y+h), font, 2, (0,255,0),2)
                        else:
                            cv2.putText(img, "Unknown",(x,y+h), font, 2, (0,0,255),2)
                            counter += 1
                            #print("First conter", counter)

                        # Printing that number below the face
                        # @Prams cam image, id, location,font style, color, stroke

                    cv2.imshow("Face",img)
                    #print("Counter is ", counter)
                    if counter == 25:
                        break
                    
                    if(cv2.waitKey(1) == ord('q')):
                        break
                    elif(userId != 0):
                        cv2.waitKey(1000)
                        cam.release()
                        cv2.destroyAllWindows()

                        user_exist = user_exists(userId)
                        if not user_exist:
                            messages.error(request, 'Opps! Your face exist but your index number conflicts.')
                            return render(request, 'addstudent.html', context)
                        
                        student_id_exits = Student.objects.filter(student_id=student_id).first()
                        
                        if student_id_exits:
                            messages.error(request, 'Opps! Your index number exist.')
                            return render(request, 'addstudent.html', context)
                        else:
                        
                            create_dataset(request, student_id)
                            break

                student.save()
                messages.success(request, 'Student registration successful!')
                return render(request, 'addstudent.html', context)
                
            else:
                return render(request, 'addstudent.html', context)
    form = StudentForm()
    context = {'form': form}
    return render(request, 'addstudent.html', context)





def take_attendance(request):

    if not request.user.is_authenticated:
        messages.error(request, 'You need to login to this page')
        return render(request,'Login.html')
    else :
        form = AttendanceForm()
        if request.method =='POST':
            form = AttendanceForm(request.POST or None)

            if form.is_valid():
                lecture = request.POST.get('lecture')
                student_class = request.POST.get('student_class')

                markAllAttendance(student_class, lecture)
                
                counter = 0
    
                faceDetect = cv2.CascadeClassifier(str(BASE_DIR)+'/ml/haarcascade_frontalface_default.xml')

                cam = cv2.VideoCapture(0)
                # creating recognizer
                rec = cv2.face.LBPHFaceRecognizer_create()
                # loading the training data
                rec.read(str(BASE_DIR)+'/ml/recognizer/trainingData.yml')
                getId = 0
                font = cv2.FONT_HERSHEY_SIMPLEX
                userId = 0
                while(True):
                    ret, img = cam.read()
                    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                    faces = faceDetect.detectMultiScale(gray, 1.3, 5)
                    for(x,y,w,h) in faces:
                        cv2.rectangle(img,(x,y),(x+w,y+h), (0,255,0), 2)

                        getId,conf = rec.predict(gray[y:y+h, x:x+w]) #This will predict the id of the face

                        #print conf;
                        if conf<25:
                            userId = getId
                            cv2.putText(img, "Detected",(x,y+h), font, 2, (0,255,0),2)
                        else:
                            cv2.putText(img, "Unknown",(x,y+h), font, 2, (0,0,255),2)
                            counter+=1

                        # Printing that number below the face
                        # @Prams cam image, id, location,font style, color, stroke

                    cv2.imshow("Face",img)
                    
                    # if counter == 35:
                    #     cv2.waitKey(1000)
                    #     cam.release()
                    #     cv2.destroyAllWindows()
                    #     context = {'face_message':'Opps! Face not found.'}
                    #     return render(request, 'checkout.html', context)
                    
                    
                    if(cv2.waitKey(1) == ord('q')):
                        break
                    elif(userId != 0):
                        # cv2.waitKey(1000)
                        # cam.release()
                        # cv2.destroyAllWindows()

                        student_id = userId
                        markPresent(student_id, student_class, lecture)
                
                
                messages.success(request, 'Attendance marked successfully!')
            else:
                messages.error(request, 'There was an error saving class info!')
      
    context = {'form': form}
    return render(request, 'take_attendance.html', context)



def markAllAttendance(student_class, lecture):
    
    classes = Class.objects.filter(student_class=student_class).first()
    students = Student.objects.filter(Class=classes)
    lecture = Lecture.objects.filter(id=lecture).first()

    for student in students:
        absent_student = Attendance(student=student, lecture=lecture, student_class=classes, present=False)
        absent_student.save()



def markPresent(student_id, student_class, lecture):
    
    classes = Class.objects.filter(student_class=student_class).first()
    lecture = Lecture.objects.filter(id=lecture).first()
    student_id = Student.objects.filter(student_id=student_id).first()
    
    present_attendance = Attendance.objects.filter(date_created__date=datetime.date.today(), student=student_id, student_class=classes).first()

    #print(present_attendance)
    if present_attendance:
        Attendance.objects.filter(date_created__date=datetime.date.today(), student=student_id, student_class=classes).update(present = True)
    
    


 #This function is used to create a dataset of images of the user
def create_dataset(request, student_id):
    #print request.POST

    #print (cv2.__version__)
    # Detect face
    #Creating a cascade image classifier
    # print(BASE_DIR)
    faceDetect = cv2.CascadeClassifier(str(BASE_DIR)+'/ml/haarcascade_frontalface_default.xml')
    #camture images from the webcam and process and detect the face
    # takes video capture id, for webcam most of the time its 0.
    cam = cv2.VideoCapture(0)

    # Our identifier
    # We will put the id here and we will store the id with a face, so that later we can identify whose face it is
    
    # Our dataset naming counter
    sampleNum = 0
    # Capturing the faces one by one and detect the faces and showing it on the window
    while(True):
        # Capturing the image
        #cam.read will return the status variable and the captured colored image
        ret, img = cam.read()
        #the returned img is a colored image but for the classifier to work we need a greyscale image
        #to convert
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        #To store the faces
        #This will detect all the images in the current frame, and it will return the coordinates of the faces
        #Takes in image and some other parameter for accurate result
        faces = faceDetect.detectMultiScale(gray, 1.3, 5)
        #In above 'faces' variable there can be multiple faces so we have to get each and every face and draw a rectangle around it.
        for(x,y,w,h) in faces:
            # Whenever the program captures the face, we will write that is a folder
            # Before capturing the face, we need to tell the script whose face it is
            # For that we will need an identifier, here we call it id
            # So now we captured a face, we need to write it in a file
            sampleNum = sampleNum+1
            # Saving the image dataset, but only the face part, cropping the rest
            cv2.imwrite(str(BASE_DIR)+'/ml/dataset/user.'+str(student_id)+'.'+str(sampleNum)+'.jpg', gray[y:y+h,x:x+w])
            # @params the initial point of the rectangle will be x,y and
            # @params end point will be x+width and y+height
            # @params along with color of the rectangle
            # @params thickness of the rectangle
            cv2.rectangle(img,(x,y),(x+w,y+h), (0,255,0), 2)
            # Before continuing to the next loop, I want to give it a little pause
            # waitKey of 100 millisecond
            cv2.waitKey(250)

        #Showing the image in another window
        #Creates a window with window name "Face" and with the image img
        cv2.imshow("Face",img)
        #Before closing it we need to give a wait command, otherwise the open cv wont work
        # @params with the millisecond of delay 1
        cv2.waitKey(1)
        #To get out of the loop
        if(sampleNum>35):
            
            break
        # if(sampleNum != 35 and )
    #releasing the cam
    cam.release()
    # destroying all the windows
    cv2.destroyAllWindows()





































def capture(request):
    _ids = request.POST['IDs']
    _path='./training-data/s'+_ids
    face_cascade = cv2.CascadeClassifier('./static/haarcascade_frontalface_default.xml')
    if not request.user.is_authenticated:
        return render(request,'Login.html')
    print(_ids)
    if request.method=="POST":
        try:
            os.mkdir(_path)
            print("Directory " , _path ,  " Created ") 
        except FileNotFoundError:
            print("Directory " , _path ,  " already exists")
            return render(request,'capture.html',{'successmsg':'Directory not found'})
        cam = cv2.VideoCapture(0)
        cv2.namedWindow("Capture the Faces")
        img_counter = 1
        mins=0
        while mins!=100:
            ret, frame = cam.read()
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray,scaleFactor=1.2, minNeighbors=5)
            cv2.imshow("Capture the Faces Space to take a photo and esc to exit", frame)
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
                sub_face = frame[y:y+h, x:x+w]
                img_name = "./"+_path+"/"+"{}.png".format(img_counter)
                cv2.imwrite(img_name, sub_face)
                print("{} written!".format(img_name))
                img_counter += 1
            mins+=1
        cam.release()
        cv2.destroyAllWindows()   
    return render(request,'capture.html',{'successmsg':'success'})

#euledian

#lecture Capturing

def Lec_capture(request):
    _ids = request.POST['IDs']
    _path='./traininglec/Lecture'+_ids
    face_cascade = cv2.CascadeClassifier('./static/haarcascade_frontalface_default.xml')
    if not request.user.is_authenticated:
        return render(request,'Login.html')
    print(_ids)
    if request.method=="POST":
        try:
            os.mkdir(_path)
            print("Directory " , _path ,  " Created ") 
        except FileExistsError:
            print("Directory " , _path ,  " already exists")
            #changes need to be done here
        cam = cv2.VideoCapture(0)
        cv2.namedWindow("Capture the Faces")
        img_counter = 1
        while True:
            ret, frame = cam.read()
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray,scaleFactor=1.2, minNeighbors=5)
            cv2.imshow("Capture the Faces Space to take a photo and esc to exit", frame)
            if not ret:
                break
            k = cv2.waitKey(1)
            if k%256 == 27:
                print("Escape hit, closing...")
                break
            elif k%256 == 32:
                img_name = "./"+_path+"/"+"{}.png".format(img_counter)
                cv2.imwrite(img_name, frame)
                print("{} written!".format(img_name))
                img_counter += 1
        cam.release()
        cv2.destroyAllWindows()   
    return render(request,'capture.html',{'successmsg':'success'})



def detect_face(image):
    
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier('./static/haarcascade_frontalface_default.xml')
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5);
    if (len(faces) == 0):
        return None, None
    (x, y, w, h) = faces[0]
    return gray[y:y+w, x:x+h], faces[0]

def training(request):
    if not request.user.is_authenticated:
        return render(request,'Login.html')
    faceinstance =[]
    dirs = os.listdir('./training-data/')
    faces = []
    labels = []
    for dir_name in dirs:
        if not dir_name.startswith("s"):
            continue;
        label = int(dir_name.replace("s", ""))
        subject_dir_path ='training-data' + "/" + dir_name        
        subject_images_names = os.listdir(subject_dir_path)
        recognizer = cv2.face.LBPHFaceRecognizer_create()
        for image_name in subject_images_names:
            if image_name.startswith("."):
                continue;
            image_path = subject_dir_path + "/" + image_name
            image = cv2.imread(image_path)
            cv2.imshow("Training on image...", cv2.resize(image, (400, 500)))
            cv2.waitKey(100)
            face, rect = detect_face(image) 
            if face is not None:
                faces.append(face)
                labels.append(label)
            
    recognizer.train(faces,np.array(labels))
    recognizer.save("./trainingdata.yml")
    cv2.destroyAllWindows()
    cv2.waitKey(1)
    cv2.destroyAllWindows()
    
    context = {'faces':'Successfully','label':'Trained'}
    return render(request,'main.html',context)

#Training Lecture data
def training_lec(request):
    if not request.user.is_authenticated:
        return render(request,'Login.html')
    faceinstance =[]
    dirs = os.listdir('./trainingLec/')
    faces = []
    labels = []
    for dir_name in dirs:
        if not dir_name.startswith("Lecture"):
            continue;
        label = int(dir_name.replace("Lecture", ""))
        subject_dir_path ='traininglec' + "/" + dir_name        
        subject_images_names = os.listdir(subject_dir_path)
        recognizer = cv2.face.LBPHFaceRecognizer_create()
        for image_name in subject_images_names:
            if image_name.startswith("."):
                continue;
            image_path = subject_dir_path + "/" + image_name
            image = cv2.imread(image_path)
            cv2.imshow("Training on image...", cv2.resize(image, (400, 500)))
            cv2.waitKey(100)
            face, rect = detect_face(image) 
            if face is not None:
                faces.append(face)
                labels.append(label)
            
    recognizer.train(faces,np.array(labels))
    recognizer.save("./traininglec.yml")
    cv2.destroyAllWindows()
    cv2.waitKey(1)
    cv2.destroyAllWindows()
    
    context = {'faces':'Successfully','label':'Trained'}
    return render(request,'main.html',context)



def saves(i,take,now,time,courceid): 
    takeatt = Attendance()
    takeatt.studentform_id=i
    takeatt.date=now
    takeatt.p_b=take
    takeatt.time=time
    takeatt.cid=courceid
    takeatt.save()





def excelsave(i,take,now,time,courceid):
    myData = [[id,date,p_b,studentform_id,time,cid], [i,take,now,time,courceid]]  
    myFile = open('csvexample3.csv', 'w')  
    with myFile:  
        writer = csv.writer(myFile)
        writer.writerows(myData)
  
  
  
    
def recg(request):
    if not request.user.is_authenticated:
        return render(request,'Login.html')
    if 'id' in request.GET and request.GET['id']:
        courceid= int(request.GET['id'])
        face_cascade = cv2.CascadeClassifier('./static/haarcascade_frontalface_default.xml')
        takeatt = Attendance()
        rec = cv2.face.LBPHFaceRecognizer_create()
        rec.read("trainingdata.yml")
        id=0
        cam = cv2.VideoCapture(0)
        font=cv2.FONT_HERSHEY_SIMPLEX
        now = datetime.datetime.now()
        time =now.strftime("%H:%M")
        date =now.strftime("%Y-%m-%d")
        
        att = []
        confidence=[]
        ides=[]
        print(now)
        while 1:
            ret, img = cam.read()
            print(ret)
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2,
                        minNeighbors=5,
                        minSize=(25, 25))
            now = datetime.datetime.now()
            for (x,y,w,h) in faces:
                cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
                subface=cv2.resize(gray[y:y+h, x:x+w],(280,280))
                ids,conf=rec.predict(subface)
                stname = Student.objects.get(id=ids)
                print(conf)
                
                if conf>75:
                    print(stname.id,now.strftime("%Y-%m-%d %H:%M"))
                    cv2.putText(img,str(stname.usn),(x,y+h), font, 2,20,2)
                    confidence.append(conf)
                    att.append(stname.id)
            cv2.imshow('img',img)
            k = cv2.waitKey(1)
            if k%256 == 27:
                print("Escape hit, closing...")
                break;
        att=set(att)
        Confidence ="Confidence"
        ids="Ids recoginiczed"
        print(Confidence+": "+confidence)
        print(att)    
        cv2.destroyAllWindows()
        cv2.waitKey(1)
        cv2.destroyAllWindows()
        context = {'faces': 'success','conf':confidence,'idss':att}   
        return render(request,'capture.html',context)
    else:
        return render(request,'main.html',{'faces':'Please enter the Number'})





def search(request):
    if not request.user.is_authenticated:
        return render(request,'Login.html')
    if 'q' in request.GET and request.GET['q']:
        q = request.GET['q']
        print(q)
        books = Student.objects.filter(usn=q)
        context = {'books': books, 'query': q,}
        return render(request, 'addstudent.html',context)
    else:
        return HttpResponse('Enter the Correct USN.')






def logout(request):
    _logout(request)
    return redirect(Login)





def asd(request):
    if not request.user.is_authenticated:
        return render(request,'Login.html')
    #details=Student.objects
    if 'student_class' in request.POST and request.POST['student_class']:
        

        # date = request.POST['date']
        student_class = request.POST['student_class']
        lecture = request.POST['lecture']
        # studetail = Attendance.objects.filter(student_class=student_class,date_created__date=date,lecture=lecture)
        studetail = Attendance.objects.filter(student_class=student_class,lecture=lecture)
        # print(date)
        form = AttendanceForm()
        context = {'form':form, 'stuobj':studetail}
        return render(request,'asd.html',context)
    else:
        stuobj = 'No Data \n Please Select the Branch,Section and Semester'
        form = AttendanceForm()
        context = {'form':form, 'stuobj':stuobj}
        
        return render(request,'asd.html',context)






def attendance(request):
    details=Student.objects
    if 'id' in request.GET and request.GET['id']:
        id = request.GET['id']
        
        stu = Student.objects.filter(student_id=id).first()
        stuclass = Student.objects.filter(student_id=id).all()
        
        studetail = Attendance.objects.filter(student=stu).all()
        
        
        print(stuclass)
        context = {'stuobj':studetail,'stuclassobj':stuclass}
        return render(request,'attendance.html',context)
    else:
        stuobj = 'No Data \n Please Select the Branch,Section and Semester'
        context = {'error':stuobj}
        return render(request,'attendance.html',context)
    
    
    
    

def takenatt(request):
    if not request.user.is_authenticated:
        return render(request,'Login.html')
    details=Courses.objects
    if 'branch' in request.GET and request.GET['branch']:
        branch = request.GET['branch']
        sem =  request.GET['Sem']
        
        studetail = Courses.objects.filter(branch=branch,sem=sem)
        context = {'stuobj':studetail}
        return render(request,'takenatt.html',context)
    else:
        stuobj = 'No Data \n Please Select the Branch,Section and Semester'
        context = {'error':stuobj}
        return render(request,'takenatt.html',context)












def rec_lec():
    lec_welcome="Recoginizing lecture"
    print(lec_welcome)
    face_cascade=cv2.CascadeClassifier('./static/haarcascade_frontalface_default.xml')
    rec=cv2.face.LBPHFaceRecognizer_create()
    rec.read("trainingdata.yml")
    cam=cv2.VideoCapture(0)
    cou
    while 1:
        ret, img = cam.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2,
                minNeighbors=10,
                minSize=(25, 25))
        now = datetime.datetime.now()
        for (x,y,w,h) in faces:
            cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
            ids,conf=rec.predict(gray[y:y+h,x:x+w])
            lec_name = Courses.objects.get(id=ids)
            print(conf)
            if conf>75:
                print(lec_name.id,now.strftime("%Y-%m-%d %H:%M"))
                cv2.putText(img,str(stname.usn),(x,y+h), font, 2,20,2)
                cv2.imshow('img',img)
        k = cv2.waitKey(1)
        if k%256 == 27:
            print("Escape hit, closing...")
            break;
        saves(11,True,now,now.strftime("%H:%M"),1)
        #excelsave(i,True,now,now.strftime("%H:%M"),courceid)    
    cv2.destroyAllWindows()
    cv2.waitKey(1)
    cv2.destroyAllWindows()

#Attendance using timetable
# @background(schedule=60)
# def hello():
#     now = datetime.datetime.now()
#     present_day = ((now.isoweekday() % 7)+1)
#     print(present_day)
#     present_day_time = '9:00'     # (now.strftime("%H:%M"))
#     time_list=['9:00','10:00']
#     for x in time_list:
#         if present_day_time==x:
#             present_day_time =x
#             print(present_day_time)
#             break;
#         else:
#             present_day_time='0:00'
#     if present_day > 0 and present_day_time !='0:00':
#         time_tb=time_table.objects.get(weekday=present_day,timings=present_day_time)  #0
#         if time_tb:
#             print(time_tb.id) 
#             Welcome ="Welcome To SKIT Attendance System Ready to Take Attendance"
#             print(Welcome)
#             courceid = int(time_tb.id)
#             face_cascade = cv2.CascadeClassifier('./static/haarcascade_frontalface_default.xml')
#             takeatt = Attendance()
#             rec = cv2.face.LBPHFaceRecognizer_create()
#             rec.read("trainingdata.yml")
#             id=0
#             cam = cv2.VideoCapture(0)
#             font=cv2.FONT_HERSHEY_SIMPLEX
            
#             time =now.strftime("%H:%M")
#             date =now.strftime("%Y-%m-%d")   
#             att = []
#             print(now)
#             mins=0
#             while mins!=120:
#                 ret, img = cam.read()
#                 gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#                 faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2,
#                             minNeighbors=10,
#                             minSize=(25, 25))
#                 now = datetime.datetime.now()
#                 for (x,y,w,h) in faces:
#                     cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
#                     ids,conf=rec.predict(gray[y:y+h,x:x+w])
#                     stname = Student.objects.get(id=ids)
#                     print(conf)
#                     if conf>75:
#                         print(stname.id,now.strftime("%Y-%m-%d %H:%M"))
#                         cv2.putText(img,str(stname.usn),(x,y+h), font, 2,20,2)
#                         att.append(stname.id)
#                 cv2.imshow('img',img)
#                 mins+=1
#                 k = cv2.waitKey(1)
#                 if k%256 == 27:
#                     print("Escape hit, closing...")
#                     break;
#             att=set(att)
#             for i in att:
#                 saves(i,True,now,now.strftime("%H:%M"),courceid)
#                     #excelsave(i,True,now,now.strftime("%H:%M"),courceid)    
#             cv2.destroyAllWindows()
#             cv2.waitKey(1)
#             cv2.destroyAllWindows()
#         else:
#             print("welcome")
#     else:
#         print("Not Data")

#@background(schedule=60)
def hello():
    now=datetime.datetime.now()
    present_day=((now.isoweekday() %7)+1)
    face_cascade=cv2.CascadeClassifier('./static/haarcascade_frontalface_default.xml')
    rec=cv2.face.LBPHFaceRecognizer_create()
    time =now.strftime("%H:%M")
    date =now.strftime("%Y-%m-%d")   
    
    print(now)
    if present_day>=0:
        present_day_time =   '9:00'   # (now.strftime("%H:%M")) 
        time_list=['9:00','10:00']
        for x in time_list:
            if present_day_time==x:
                present_day_time =x
                print(present_day_time)
                break
            else:
                present_day_time='0:00' 
        if present_day_time=='0:00':
            Do_no="Do Nothing"
            print(Do_no)
        else:
            rec.read('traininglec.yml')
            cam = cv2.VideoCapture(0)
            font=cv2.FONT_HERSHEY_SIMPLEX
            att_lec = []
            mins=0
            while mins!=300:
                ret, img = cam.read()
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2,
                            minNeighbors=10,
                            minSize=(25, 25))
                now = datetime.datetime.now()
                for (x,y,w,h) in faces:
                    cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
                    ids,conf=rec.predict(gray[y:y+h,x:x+w])
                    lec_name = Courses.objects.get(id=ids)
                    print(conf)
                    if conf>75:
                        print(lec_name.id,now.strftime("%Y-%m-%d %H:%M"))
                        cv2.putText(img,str(lec_name.id),(x,y+h), font, 2,20,2)
                        att_lec.append(lec_name.id)
                cv2.imshow('img',img)
                mins+=1
                print(att_lec)
            if len(att_lec):
                lec_id=att_lec
                rec.read('trainingdata.yml')
                cam = cv2.VideoCapture(0)
                font=cv2.FONT_HERSHEY_SIMPLEX
                att = []
                mins=0
                while mins!=300:
                    ret, img = cam.read()
                    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2,
                                minNeighbors=10,
                                minSize=(25, 25))
                    now = datetime.datetime.now()
                    for (x,y,w,h) in faces:
                        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
                        ids,conf=rec.predict(gray[y:y+h,x:x+w])
                        stname = Student.objects.get(id=ids)
                        print(conf)
                        if conf>70:
                            print(stname.id,now.strftime("%Y-%m-%d %H:%M"))
                            cv2.putText(img,str(stname.usn),(x,y+h), font, 2,20,2)
                            att.append(stname.id)
                    cv2.imshow('img',img)
                    mins+=1
                    k = cv2.waitKey(1)
                    if k%256 == 27:
                        print("Escape hit, closing...")
                        break;
                att=set(att)
                for i in att:
                    saves(i,True,now,now.strftime("%H:%M"),lec_id[0])
                lecid_obj=Courses.objects.filter(id=lec_id[0])
                lecid_obj=Courses.objects.get(id=1)
                subject ='Class'
                message='Class are taken by '+ str(lec_id[0]) +' at '+ str(now) +' for '+ str(len(att)) +' students.'
                from_email=settings.EMAIL_HOST_USER
                to_list=[lecid_obj.fmail,settings.EMAIL_HOST_USER]
                send_mail(subject,message,from_email,to_list,fail_silently=False)
                _mssg='Class taken'
            else:
                No_lec="Lecture Not Found"
                print(No_lec)    
                
    else:
        No_lec="Sunday"
        print(No_lec)
    

            

# @background(schedule=60)
# def hello():
#     now = datetime.datetime.now()
#     present_day = ((now.isoweekday() % 7)+1)
#     present_day_time = '9:00'     # (now.strftime("%H:%M"))
#     time_list=['9:00','10:00']
#     for x in time_list:
#         if present_day_time==x:
#             present_day_time =x
#             print(present_day_time)
#             break;
#         else:
#             present_day_time='0:00'
            
#     if present_day > 0 and present_day_time !='0:00':
#         Welcome ="Welcome To SKIT Attendance System Ready to Take Attendance"
#         print(Welcome)
#         courceid = 1
#         face_cascade = cv2.CascadeClassifier('./static/haarcascade_frontalface_default.xml')
#         takeatt = Attendance()
#         rec = cv2.face.LBPHFaceRecognizer_create()
#         rec.read("trainingdata.yml")
#         id=0
#         cam = cv2.VideoCapture(0)
#         font=cv2.FONT_HERSHEY_SIMPLEX
        
#         time =now.strftime("%H:%M")
#         date =now.strftime("%Y-%m-%d")   
#         att = []
#         print(now)
#         mins=0
#         while mins !=120:
#             ret, img = cam.read()
#             gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#             faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2,
#                         minNeighbors=10,
#                         minSize=(25, 25))
#             now = datetime.datetime.now()
#             for (x,y,w,h) in faces:
#                 cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
#                 ids,conf=rec.predict(gray[y:y+h,x:x+w])
#                 try:
#                     lec_name = Courses.objects.get(id=ids)
#                     print(conf)
#                     if conf>75:
#                         print(lec_name.id,now.strftime("%Y-%m-%d %H:%M"))
#                         cv2.putText(img,str(lec_name.id),(x,y+h), font, 2,20,2)
#                         att.append(lec_name.id)
#                 except:
#                     not_found="Lecture Not Found In Database"
#                     print(not_found)
#                     break;
#             cv2.imshow('img',img)
#             mins+=1
#             k = cv2.waitKey(1)
#             if k%256 == 27:
#                 print("Escape hit, closing...")
#                 break;
#         print(att) 
#         cv2.destroyAllWindows()
#         cv2.waitKey(1)
#         cv2.destroyAllWindows()
#     else:
#         print("Not Data")
        
def back(request):
    hello(schedule=90)
    return render(request,"main.html")





def trainingeigen(request):
    if not request.user.is_authenticated:
        return render(request,'Login.html')
    faceinstance =[]
    dirs = os.listdir('./training-data/')
    faces = []
    labels = []
    for dir_name in dirs:
        if not dir_name.startswith("s"):
            continue;
        label = int(dir_name.replace("s", ""))
        subject_dir_path ='training-data' + "/" + dir_name        
        subject_images_names = os.listdir(subject_dir_path)
        recognizer = cv2.face.EigenFaceRecognizer_create()
        for image_name in subject_images_names:
            if image_name.startswith("."):
                continue;
            image_path = subject_dir_path + "/" + image_name
            image = cv2.imread(image_path)
            cv2.imshow("Training on image...", cv2.resize(image, (100, 100)))
            cv2.waitKey(100)
            face, rect = detect_face(image) 
            
            if face is not None:
                faces.append(cv2.resize(face,(280,280)))
                labels.append(label)
            
    recognizer.train(faces,np.array(labels))
    recognizer.save("./trainingdataeigen.yml")
    cv2.destroyAllWindows()
    cv2.waitKey(1)
    cv2.destroyAllWindows()
    
    context = {'faces':'Successfully','label':'Trained'}
    return render(request,'main.html',context)





    
def recgeigen(request):
    if not request.user.is_authenticated:
        return render(request,'Login.html')
    if 'id' in request.GET and request.GET['id']:
        courceid= int(request.GET['id'])
        face_cascade = cv2.CascadeClassifier('./static/haarcascade_frontalface_default.xml')
        takeatt = Attendance()
        rec = cv2.face.EigenFaceRecognizer_create()
        rec.read("trainingdataeigen.yml")
        id=0
        cam = cv2.VideoCapture(0)
        font=cv2.FONT_HERSHEY_SIMPLEX
        now = datetime.datetime.now()
        time =now.strftime("%H:%M")
        date =now.strftime("%Y-%m-%d")
        
        att = []
        confidence=[]
        ides=[]
        print(now)
        while 1:
            ret, img = cam.read()
    
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray,scaleFactor=1.2, minNeighbors=5)
            now = datetime.datetime.now()
            for (x,y,w,h) in faces:
                cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
                subface=cv2.resize(gray[y:y+h, x:x+w],(280,280))
                ids,conf=rec.predict(subface)
                stname = Student.objects.get(id=ids)
                print(conf)
                
                print(stname.id,now.strftime("%Y-%m-%d %H:%M"))
                cv2.putText(img,str(stname.usn),(x,y+h), font, 2,20,2)
                confidence.append(conf)
                att.append(stname.id)
            cv2.imshow('img',img)
            k = cv2.waitKey(1)
            if k%256 == 27:
                print("Escape hit, closing...")
                break;
        att=set(att)
        print(confidence)
        print(att)  
        cv2.destroyAllWindows()
        cv2.waitKey(1)
        cv2.destroyAllWindows()
        context = {'faces': 'success','conf':confidence,'idss':att}
        return render(request,'capture.html',context)
    else:
        return render(request,'main.html',{'faces':'Please enter the Number'})