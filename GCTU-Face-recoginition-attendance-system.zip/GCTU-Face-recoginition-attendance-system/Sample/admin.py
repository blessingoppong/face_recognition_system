from django.contrib import admin
from Sample.models import *

admin.site.register(Lecture)
admin.site.register(Courses)
admin.site.register(Class)
admin.site.register(Student)
admin.site.register(Attendance)